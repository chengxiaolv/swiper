<template>
  <div class="content">
        <div id="taobao-best">
            <!-- Swiper -->
            <div class="swiper-container show-swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="goods">
                            <a href="#">
                                <div class="c-top">
                                    <div class="date">
                                        <div class="year">2017.12</div>
                                        <div class="day">15</div>
                                        <div class="oldyear">丁酉年</div>
                                        <div class="oldday">十月廿八</div>
                                    </div>
                                    <div class="img"><img src="../../static/images/001.jpg" width="100%"><span>「宜一器两用」</span></div>
                                </div>
                                <div class="detail">
                                        <h2>好物推荐：多功能导热奶油刀</h2>
                                        <p>一把可以切水果、涂抹果酱的多功能刀具让你的生活从此变得简单</p>
                                        <ul><li>一物多用</li><li>迅速导热</li></ul>
                                        <div class="btn">查看详情</div>
                                </div>
                            </a>    
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="goods">
                            <a href="#">
                                <div class="c-top">
                                    <div class="date">
                                        <div class="year">2017.12</div>
                                        <div class="day">15</div>
                                        <div class="oldyear">丁酉年</div>
                                        <div class="oldday">十月廿八</div>
                                    </div>
                                    <div class="img"><img src="../../static/images/002.jpg" width="100%"><span>「宜一器两用」</span></div>
                                </div>
                                <div class="detail">
                                        <h2>好物推荐：多功能导热奶油刀</h2>
                                        <p>一把可以切水果、涂抹果酱的多功能刀具让你的生活从此变得简单</p>
                                        <ul><li>一物多用</li><li>迅速导热</li></ul>
                                        <div class="btn">查看详情</div>
                                </div>
                            </a>    
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="goods">
                            <a href="#">
                                <div class="c-top">
                                    <div class="date">
                                        <div class="year">2017.12</div>
                                        <div class="day">15</div>
                                        <div class="oldyear">丁酉年</div>
                                        <div class="oldday">十月廿八</div>
                                    </div>
                                    <div class="img"><img src="../../static/images/003.jpg" width="100%"><span>「宜一器两用」</span></div>
                                </div>
                                <div class="detail">
                                        <h2>好物推荐：多功能导热奶油刀</h2>
                                        <p>一把可以切水果、涂抹果酱的多功能刀具让你的生活从此变得简单</p>
                                        <ul><li>一物多用</li><li>迅速导热</li></ul>
                                        <div class="btn">查看详情</div>
                                </div>
                            </a>    
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="goods">
                            <a href="#">
                                <div class="c-top">
                                    <div class="date">
                                        <div class="year">2017.12</div>
                                        <div class="day">15</div>
                                        <div class="oldyear">丁酉年</div>
                                        <div class="oldday">十月廿八</div>
                                    </div>
                                    <div class="img"><img src="../../static/images/004.jpg" width="100%"><span>「宜一器两用」</span></div>
                                </div>
                                <div class="detail">
                                        <h2>好物推荐：多功能导热奶油刀</h2>
                                        <p>一把可以切水果、涂抹果酱的多功能刀具让你的生活从此变得简单</p>
                                        <ul><li>一物多用</li><li>迅速导热</li></ul>
                                        <div class="btn">查看详情</div>
                                </div>
                            </a>    
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="goods">
                            <a href="#">
                                <div class="c-top">
                                    <div class="date">
                                        <div class="year">2017.12</div>
                                        <div class="day">15</div>
                                        <div class="oldyear">丁酉年</div>
                                        <div class="oldday">十月廿八</div>
                                    </div>
                                    <div class="img"><img src="../../static/images/005.jpg" width="100%"><span>「宜一器两用」</span></div>
                                </div>
                                <div class="detail">
                                        <h2>好物推荐：多功能导热奶油刀</h2>
                                        <p>一把可以切水果、涂抹果酱的多功能刀具让你的生活从此变得简单</p>
                                        <ul><li>一物多用</li><li>迅速导热</li></ul>
                                        <div class="btn">查看详情</div>
                                </div>
                            </a>    
                        </div>
                    </div>
                    <div class="swiper-slide last-slide">
                        <span class="icon"></span>
                        <p class="text">右滑查看更多</p>
                    </div>
                </div>
            </div>
            
            <div class="mask"></div>
            <div class="swiper-container bg-swiper swiper-no-swiping">
                <div class="swiper-wrapper">
                <div class="swiper-slide"><img src="../../static/images/blur001.jpg"></div>
                <div class="swiper-slide"><img src="../../static/images/blur002.jpg"></div>
                <div class="swiper-slide"><img src="../../static/images/blur003.jpg"></div>
                <div class="swiper-slide"><img src="../../static/images/blur004.jpg"></div>
                <div class="swiper-slide"><img src="../../static/images/blur005.jpg"></div>
                
                </div>
            </div>
        </div>
        <!-- <div>
            <img src="../../static/images/goods.jpg" width="100%">
        </div> -->
        <!-- <div class="bottom"><img src="../../static/images/bottom.png" width="100%"></div> -->
  </div>
</template>

<script>
    export default {
    data () {
        return {

        }
    }
    }
</script>

<style scoped>
    @import "../../static/swiper.min.css";

    #taobao-best {
        position: relative;
        height: 660px;
    }

    .show-swiper {
        z-index: 3;
        top: 80px;
    }

    .show-swiper .swiper-slide {
        width: 395px;
    }

    .show-swiper .swiper-slide:last-child {
        width: 95px;
        color: #fff;
    }

    .show-swiper .swiper-slide:last-child .icon {
        width: 32px;
        height: 32px;
        background: url(../../static/images/more-icon.png) no-repeat center 50%/100% 100%;
        display: block;
        float: left;
        margin-top: 260px;
        margin-left: 5px;
    }

    .show-swiper .swiper-slide:last-child .text {
        width: 21px;
        font-size: 21px;
        margin-top: 180px;
        margin-left: 10px;
        line-height: 1.5;
        float: left;
    }

    .show-swiper .swiper-slide .goods {
        width: 375px;
        padding: 10px;
        height: 500px;
        margin: 40px 0;
        border-radius: 8px;
        background: url(../../static/images/goods-bg.png);
    }

    .goods .c-top {
        border-bottom: 1px solid #dcdcdd;
        width: 100%;
        float: left;
    }

    .goods .date {
        width: 119px;
        height: 318px;
        border-right: 1px solid #adb4ba;
        float: left;
    }

    .goods .date .year {
        color: #050403;
        font-weight: bold;
        text-align: center;
        margin-top: 35px;
    }

    .goods .date .day {
        font-size: 55px;
        text-align: center;
        margin-top: 5px;
        font-weight: bolder;
        color: #080704;
    }

    .goods .date .oldyear {
        color: #050403;
        margin-top: 5px;
        font-size: 22px;
        width: 22px;
        line-height: 1.4;
        margin-left: 30px;
        float: left;
    }

    .goods .date .oldday {
        color: #050403;
        margin-top: 5px;
        font-size: 22px;
        line-height: 1.4;
        width: 22px;
        margin-right: 30px;
        float: right;
    }

    .goods .img {
        width: 255px;
        float: right;
    }

    .goods .img span {
        color: #1a1918;
        font-size: 32px;
        text-align: center;
        line-height: 60px;
        display: block;
    }

    .goods .img img {
        border-top-right-radius: 8px;
    }

    .goods .detail {
        width: 335px;
        margin: 0 20px;
        float: left;
    }

    .goods .detail h2 {
        font-weight: normal;
        color: #312f30;
        font-size: 23px;
        margin-bottom: 0;
    }

    .goods .detail p {
        color: #979797;
        line-height: 1.5;
        font-size: 18px;
        margin-top: 8px;
    }

    .goods .detail ul {
        padding-left: 0;
        margin-left: 20px;
        float: left;
        margin-top: 0;
    }

    .goods .detail ul li {
        float: left;
        margin-right: 25px;
        color: #737373;
    }

    .goods .detail .btn {
        float: right;
        margin-right: -10px;
        margin-top: -5px;
        width: 120px;
        height: 40px;
        line-height: 40px;
        color: #fff;
        text-align: center;
        border-radius: 20px;
        background: linear-gradient(90deg, #ffe13c, #ffa70f);
    }

    .bg-swiper {
        position: absolute;
        width: 100%;
        height: 640px;
        top: 0;
        z-index: 1;
    }

    .bg-swiper .swiper-slide {
        background: #000;
    }

    .bg-swiper .swiper-slide img {
        /* filter: blur(5px);性能太卡*/
        width: 100%;
        opacity: .5;
    }

    .mask {
        /*clip-path: polygon(0px 80px, 640px 0px, 640px 170px,0px 170px);兼容性差
        background:#fff;*/
        background: url(../../static/images//mask.png) no-repeat center bottom/100% auto;
        position: absolute;
        bottom: 0;
        z-index: 2;
        width: 100%;
        height: 170px;
    }

    .bottom {
        position: fixed;
        bottom: 0;
        width: 640px;
    }

    .bottom img {
        display: block;
    }
</style>
